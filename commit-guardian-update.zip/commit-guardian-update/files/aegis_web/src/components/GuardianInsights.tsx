'use client';

import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { Banknote, History, HeartPulse, CheckCircle2, Undo2, Hand } from 'lucide-react';

// ---------- Types shared with page.tsx ----------

export type FindingRisk = {
  finding_id: string;
  title: string;
  location: string;
  severity: string;
  category: string;
  category_label: string;
  risk_kzt: number;
};

export type FinancialRisk = {
  total_kzt: number;
  regulatory_kzt: number;
  incident_kzt: number;
  legal_basis: string;
  headline: string;
  top_findings: FindingRisk[];
  assumptions: string[];
};

export type GhostSecret = {
  secret_type: string;
  masked_value: string;
  file_path: string;
  line: number;
  introduced: { short: string; author: string; date: string; subject: string };
  removed: { short: string; author: string; date: string; subject: string } | null;
  exposure_days: number;
};

export type HealingReport = {
  before_score: number;
  before_grade: string;
  after_score: number;
  after_grade: string;
  before_findings: number;
  after_findings: number;
  before_risk_kzt: number;
  after_risk_kzt: number;
  fixed_count: number;
  fixes: { file_path: string; fixers: string[]; diff: string; fixed_findings: string[]; verified: boolean }[];
  reverted_files: string[];
  manual_actions: { title: string; location: string; severity: string; action: string }[];
};

export const formatKzt = (n: number) => `${Math.round(n).toLocaleString('ru-RU').replace(/,/g, ' ')} ₸`;

const card = 'bg-[#1f1e1b] border border-[#2b2926] rounded-xl p-4';
const label = 'text-xs font-mono uppercase tracking-wider text-[#a09d96] mb-2 flex items-center gap-1.5';

// ---------- Financial risk ----------

export function RiskCard({ risk }: { risk: FinancialRisk }) {
  const top = risk.top_findings[0]?.risk_kzt || 1;
  return (
    <div className={card}>
      <div className={label}>
        <Banknote className="w-3.5 h-3.5" aria-hidden="true" /> Финансовый риск
      </div>
      <div className={`text-2xl font-semibold font-mono ${risk.total_kzt ? 'text-red-300' : 'text-emerald-300'}`}>
        {risk.total_kzt ? `до ${formatKzt(risk.total_kzt)}` : '0 ₸'}
      </div>
      <p className="text-[11px] text-[#a09d96] mt-1">
        Штраф: {formatKzt(risk.regulatory_kzt)}
        {risk.incident_kzt ? ` · инцидент: ${formatKzt(risk.incident_kzt)}` : ''} · {risk.legal_basis}
      </p>
      {risk.top_findings.length > 0 && (
        <ul className="mt-3 space-y-1.5">
          {risk.top_findings.slice(0, 4).map((r) => (
            <li key={r.finding_id} className="text-[11px]">
              <div className="flex justify-between gap-2">
                <span className="truncate text-[#e5e2dc]" title={r.title}>{r.title}</span>
                <span className="font-mono text-red-300 shrink-0">{formatKzt(r.risk_kzt)}</span>
              </div>
              <div className="h-1 rounded bg-[#2b2926] mt-1 overflow-hidden">
                <div className="h-full bg-red-400/70" style={{ width: `${Math.max(4, (r.risk_kzt / top) * 100)}%` }} />
              </div>
            </li>
          ))}
        </ul>
      )}
      <details className="mt-2 text-[10px] text-[#7d7a74]">
        <summary className="cursor-pointer">Допущения модели</summary>
        <ul className="mt-1 list-disc pl-4 space-y-0.5">
          {risk.assumptions.map((a) => <li key={a}>{a}</li>)}
        </ul>
      </details>
    </div>
  );
}

// ---------- Git Time Machine ----------

export function GhostSecretsCard({ ghosts }: { ghosts: GhostSecret[] }) {
  if (!ghosts.length) return null;
  return (
    <div className={`${card} border-red-500/40`}>
      <div className={label}>
        <History className="w-3.5 h-3.5" aria-hidden="true" /> Машина времени Git
      </div>
      {ghosts.map((g) => (
        <div key={`${g.introduced.short}-${g.masked_value}`} className="text-xs">
          <div className="text-[#faf9f5] font-semibold">
            👻 {g.secret_type} <code className="font-mono text-red-300">{g.masked_value}</code>
          </div>
          <ol className="relative border-l border-[#3a3733] ml-1.5 mt-2 space-y-2 pl-4">
            <li>
              <span className="absolute -left-[5px] w-2.5 h-2.5 rounded-full bg-red-400" />
              <span className="font-mono text-[#a09d96]">{g.introduced.date.slice(0, 10)} · {g.introduced.short}</span>
              <div className="text-[#e5e2dc]">Добавлен: «{g.introduced.subject}» — {g.introduced.author}</div>
            </li>
            {g.removed && (
              <li>
                <span className="absolute -left-[5px] w-2.5 h-2.5 rounded-full bg-amber-400" />
                <span className="font-mono text-[#a09d96]">{g.removed.date.slice(0, 10)} · {g.removed.short}</span>
                <div className="text-[#e5e2dc]">«Удалён»: «{g.removed.subject}»</div>
              </li>
            )}
            <li>
              <span className="absolute -left-[5px] w-2.5 h-2.5 rounded-full bg-red-500 animate-pulse" />
              <span className="font-mono text-red-300">сегодня</span>
              <div className="text-[#e5e2dc]">До сих пор восстанавливается через <code>git log -p</code></div>
            </li>
          </ol>
          <div className="mt-2 font-mono text-red-300">Окно утечки: {g.exposure_days} дн. — ключ нужно отозвать</div>
        </div>
      ))}
    </div>
  );
}

// ---------- Self-Healing ----------

function useCountUp(target: number, from: number, run: boolean, ms = 1400) {
  const [value, setValue] = useState(from);
  useEffect(() => {
    if (!run) return;
    let frame = 0;
    const start = performance.now();
    const tick = (now: number) => {
      const t = Math.min(1, (now - start) / ms);
      const eased = 1 - Math.pow(1 - t, 3);
      setValue(from + (target - from) * eased);
      if (t < 1) frame = requestAnimationFrame(tick);
    };
    frame = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(frame);
  }, [target, from, run, ms]);
  return run ? value : from;
}

function DiffView({ diff }: { diff: string }) {
  return (
    <pre className="text-[11px] font-mono leading-relaxed overflow-x-auto bg-[#141311] rounded-md p-3 mt-2">
      {diff.split('\n').map((line, i) => {
        const color = line.startsWith('+') && !line.startsWith('+++')
          ? 'text-emerald-300 bg-emerald-500/10'
          : line.startsWith('-') && !line.startsWith('---')
          ? 'text-red-300 bg-red-500/10'
          : line.startsWith('@@') ? 'text-sky-300' : 'text-[#a09d96]';
        return <div key={i} className={color}>{line || ' '}</div>;
      })}
    </pre>
  );
}

export function HealPanel({ report }: { report: HealingReport }) {
  const score = useCountUp(report.after_score, report.before_score, true);
  const risk = useCountUp(report.after_risk_kzt, report.before_risk_kzt, true, 1800);
  const scoreColor = score >= 80 ? 'text-emerald-300' : score >= 50 ? 'text-amber-300' : 'text-red-300';

  return (
    <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} className={`${card} border-emerald-500/40`}>
      <div className={label}>
        <HeartPulse className="w-3.5 h-3.5" aria-hidden="true" /> Самоисцеление — патч → пересканирование → доказательство
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div>
          <div className="text-[10px] text-[#a09d96] font-mono">SECURITY SCORE</div>
          <div className={`text-3xl font-semibold font-mono ${scoreColor}`}>
            {report.before_grade} → {Math.round(score)}
          </div>
          <div className="text-[11px] text-[#a09d96] font-mono">{report.before_score} → {report.after_score} ({report.after_grade})</div>
        </div>
        <div>
          <div className="text-[10px] text-[#a09d96] font-mono">НАХОДКИ</div>
          <div className="text-3xl font-semibold font-mono text-[#faf9f5]">
            {report.before_findings} → {report.after_findings}
          </div>
          <div className="text-[11px] text-emerald-300 font-mono">исправлено и подтверждено: {report.fixed_count}</div>
        </div>
        <div>
          <div className="text-[10px] text-[#a09d96] font-mono">РИСК</div>
          <div className="text-xl font-semibold font-mono text-emerald-300">{formatKzt(risk)}</div>
          <div className="text-[11px] text-[#a09d96] font-mono">было {formatKzt(report.before_risk_kzt)}</div>
        </div>
      </div>

      <div className="mt-4 space-y-3">
        {report.fixes.map((fix) => (
          <details key={fix.file_path} className="group" open={report.fixes.length <= 2}>
            <summary className="cursor-pointer text-xs flex items-center gap-2 text-[#faf9f5]">
              <CheckCircle2 className={`w-3.5 h-3.5 ${fix.verified ? 'text-emerald-400' : 'text-[#7d7a74]'}`} aria-hidden="true" />
              <code className="font-mono">{fix.file_path}</code>
              <span className="text-[#a09d96]">— {fix.fixers.join(' · ')}</span>
            </summary>
            <ul className="mt-1 ml-6 text-[11px] text-emerald-300 list-none space-y-0.5">
              {fix.fixed_findings.map((t, i) => <li key={i}>− {t}</li>)}
            </ul>
            <DiffView diff={fix.diff} />
          </details>
        ))}
        {report.reverted_files.map((f) => (
          <div key={f} className="text-[11px] text-amber-300 flex items-center gap-1.5">
            <Undo2 className="w-3 h-3" aria-hidden="true" /> {f}: патч откатан — он не снижал риск
          </div>
        ))}
      </div>

      {report.manual_actions.length > 0 && (
        <div className="mt-4 border-t border-[#2b2926] pt-3">
          <div className={label}>
            <Hand className="w-3.5 h-3.5" aria-hidden="true" /> Нужен человек
          </div>
          {report.manual_actions.map((m, i) => (
            <div key={i} className="text-[11px] text-[#e5e2dc] mb-1.5">
              <span className="font-mono text-red-300">[{m.severity}]</span> {m.title}{' '}
              <code className="text-[#a09d96]">{m.location}</code>
              <div className="text-[#a09d96]">→ {m.action}</div>
            </div>
          ))}
        </div>
      )}
    </motion.div>
  );
}
