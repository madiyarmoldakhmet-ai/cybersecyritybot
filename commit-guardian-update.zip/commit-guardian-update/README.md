# Commit Guardian — обновление (6 коммитов)

Основа: `main` @ `ca14f80` (feat(colab): GPU notebook…). Автор коммитов — **Wexflyrlx18**.
Тесты: **92 passed** (было 57). Фронтенд собирается (`npm run build`), сценарий проверен в браузере.

## Что внутри

| Путь | Что это |
|---|---|
| `commit-guardian-update.bundle` | Все 6 коммитов с историей и авторством — **рекомендуемый способ** |
| `patches/0001…0006-*.patch` | Те же коммиты в формате `git format-patch` (для `git am`) |
| `all-changes.diff` | Один общий дифф относительно `main` |
| `files/` | Готовые изменённые и новые файлы по их путям в репозитории |
| `screenshot-*.png` | Демо-аудит и самоисцеление в веб-консоли |

## Как применить (выберите один способ)

**1. Bundle — сохраняет коммиты и авторство (лучше всего)**
```bash
cd cybersecyritybot && git checkout main && git pull
git fetch /путь/к/commit-guardian-update.bundle claude/cybersecurity-bot-analysis-9gwitp:claude/cybersecurity-bot-analysis-9gwitp
git push -u origin claude/cybersecurity-bot-analysis-9gwitp     # затем PR в main
```

**2. Патчи — тоже сохраняют авторство**
```bash
cd cybersecyritybot && git checkout -b claude/cybersecurity-bot-analysis-9gwitp origin/main
git am /путь/к/patches/*.patch
```

**3. Просто файлы** — скопировать содержимое `files/` в корень репозитория поверх существующих
(авторство коммитов в этом случае не сохранится).

После применения: `pip install -r requirements.txt && pytest -q`, для веба — `cd aegis_web && npm ci && npm run build`.

## Что сделано

1. **TaintEngine с настоящим data-flow** (`aegis/scanners/taint_engine.py`) — taint идёт по переменным, f-строкам,
   контейнерам и между функциями/файлами; route-параметры FastAPI/Flask — источники; `uid = int(uid)` очищает только
   `uid`; `cursor.execute(sql, params)` не считается уязвимостью; свой CWE на каждый тип стока.
2. **Сканер секретов** (`secret_scanner.py`) — исправлены сломанные регулярки (`[sk|rk]`, `gh[p|o|u|s|r]`),
   добавлены Telegram/Google/Slack/OpenAI, секреты маскируются в отчётах и Telegram.
3. **👻 Машина времени Git** (`aegis/scanners/git_history.py`) — секреты, «удалённые» из кода, но живые в истории:
   кто добавил, кем удалён, окно утечки в днях. Демо строит настоящую историю (`aegis/core/demo_history.py`).
4. **💸 Риск в тенге** (`aegis/scanners/risk_model.py`) — ст. 79 КоАП РК (30–2000 МРП, МРП 2026 = 4 325 ₸ — сверить
   с официальным источником) + стоимость инцидента из `.aegis.yml` (`risk:`). В PDF, Telegram, PR, API, веб-консоли.
5. **🩹 Самоисцеление с доказательством** (`aegis/core/self_heal.py`) — патч копии кода → пересканирование →
   остаются только подтверждённые фиксы, плохие откатываются. Демо: **F (0) → B (70)**, 14 → 4 находки,
   риск 83,65 млн → 8,65 млн ₸. `POST /api/scan/demo/heal`, CLI `aegis heal <путь> --apply`.
6. **Веб-консоль** (`aegis_web/src/components/GuardianInsights.tsx`) — карточки риска и Машины времени, кнопка
   «Исцелить автоматически» с анимацией и диффами.

Новые переменные окружения (`.env.example`): `GIT_HISTORY_SCAN_ENABLED`, `GIT_HISTORY_MAX_COMMITS`, `WEBHOOK_CLONE_DEPTH`.
